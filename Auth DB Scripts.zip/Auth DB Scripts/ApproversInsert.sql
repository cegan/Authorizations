
Delete from Employee

INSERT INTO [Authorizations].[dbo].[Employee]([NetworkId],[Password],[NameFirst],[NameLast],[DeviceToken],[Title])
VALUES('EganC','xxx','Casey','Egan', 'ec2c9674df4a2f1bc080f911464a88bd682fd7c976573d2e5534f812b2ecf41c', 'Application Developer')
GO

INSERT INTO [Authorizations].[dbo].[Employee]([NetworkId],[Password],[NameFirst],[NameLast],[DeviceToken],[Title])
VALUES('User1','xxx','User 1','', '03367d9e1134db1d6cb52d0d719ec1361d82357f7272774fae7052099227d67d', 'Demo User')
GO

INSERT INTO [Authorizations].[dbo].[Employee]([NetworkId],[Password],[NameFirst],[NameLast],[DeviceToken],[Title])
VALUES('User2','xxx','User 2','', '', 'Demo User')
GO

