USE Authorizations
GO
ALTER TABLE dbo.AchAuthorizations
ADD CONSTRAINT FK_Authorizations_AchAuthorizations FOREIGN KEY (ContactInformation_ID) 
    REFERENCES ContactInformation (Id) 
    ON DELETE CASCADE
    ON UPDATE CASCADE
;
GO