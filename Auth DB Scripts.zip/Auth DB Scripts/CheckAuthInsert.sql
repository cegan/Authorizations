
Use Authorizations

--Eganc

delete from [CheckAuthorizations]

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Bugs Bunny','EganC','501-687129-571','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Daffy Duck','EganC','003-690912-165','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Elmer Fudd','EganC','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Petunia Pig','EganC','676-19384483-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Speedy Gonzales','EganC','001-1818111-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tweety Pie','EganC','324-56567-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Porky The Pig','EganC','939-19385-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Little Blabbermouse','EganC','830-20384-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Cecil Turtle','EganC','293-82894-333','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Foghorn Leghorn','EganC','929-299222-929','Please Approve this ASAP',3594.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Hippety Hopper','EganC','281-393932-221','Please Approve this ASAP',9691.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Wile E. Coyote','EganC','111-90119191-221','Please Approve this ASAP',2931.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Miss Prissy','EganC','3434-60922992-555','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Bugs Bunny','EganC','2929-919191-121','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Daffy Duck','EganC','1919-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Elmer Fudd','EganC','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Sam Sheepdog','EganC','676-19384483-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Babbit and Catstello','EganC','001-1818111-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO











--User1

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Casey Egan','User1','324-56567-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Nick Egan','User1','939-19385-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kyle Egan','User1','830-20384-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Phillip Wolfe','User1','293-82894-333','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Jeremy Paulson','User1','929-299222-929','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Stephanie Paulson','User1','281-393932-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Lisa Szajkowski','User1','111-90119191-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Edward Martinez','User1','3434-60922992-555','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Robert Szajkowski','User1','2929-919191-121','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Lori Morasco','User1','1919-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Becky Hansen','User1','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Stephanie Culbertson','User1','676-19384483-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Zeus Egan','User1','001-1818111-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO


INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kent Webb','User1','324-56567-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Beth Ethen','User1','939-19385-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Jeremy Williams','User1','830-20384-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kyle Franzen','User1','293-82894-333','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Eric Summers','User1','929-299222-929','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Steve Gocke','User1','281-393932-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kent Webb','User1','111-90119191-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mike Friedman','User1','3434-60922992-555','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tim Nelson','User1','2929-919191-121','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Denis Kirlin','User1','1919-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Doug Cory','User1','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Ken Johnson','User1','676-19384483-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Carmin Fogerty','User1','001-1818111-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO






--User2

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Homer Simpson','User2','324-565617-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Woody Woodpecker','User2','001-901127-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Ren and Stimpy','User2','644-872004-173','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Fred and Barney','User2','939-193851-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Betty Boop','User2','830-203584-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mickey Mouse','User2','293-828394-549','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Scooby-Doo','User2','929-299222-004','Please Approve this ASAP',120.56,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Winnie the Pooh','User2','281-393932-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Felix the Cat','User2','438-002836-841','Please Approve this ASAP',3812.93,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tweety and Sylvester','User2','929-928480-121','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Donald Duck','User2','301-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Elmer Fudd','User2','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mighty Mouse','User2','676-19384483-583','Please Approve this ASAP',907.33,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tom and Jerry','User2','871-3765651-221','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO
