Use Authorizations
delete from [WireAuthorizations]
--Eganc

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Homer Simpson','EganC','324-565617-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Woody Woodpecker','EganC','001-901127-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Ren and Stimpy','EganC','644-872004-173','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Fred and Barney','EganC','939-193851-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Betty Boop','EganC','830-203584-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mickey Mouse','EganC','293-828394-549','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Scooby-Doo','EganC','929-299222-004','Please Approve this ASAP',120.56,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Winnie the Pooh','EganC','281-393932-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Felix the Cat','EganC','438-002836-841','Please Approve this ASAP',3812.93,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tweety and Sylvester','EganC','929-928480-121','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Donald Duck','EganC','301-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Elmer Fudd','EganC','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mighty Mouse','EganC','676-19384483-583','Please Approve this ASAP',907.33,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tom and Jerry','EganC','871-3765651-221','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO










--User1

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Casey Egan','User1','324-56567-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Beth Webb','User1','939-19385-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Jeremy Franzen','User1','830-20384-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kyle Sommers','User1','293-82894-333','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Eric Gocke','User1','929-299222-929','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Steve Ethen','User1','281-393932-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kent Egan','User1','111-90119191-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mike Williams','User1','3434-60922992-555','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Bugs Bunny','User1','2929-919191-121','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Daffy Duck','User1','1919-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Elmer Fudd','User1','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Cookie Monster','User1','676-19384483-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Big Bird','User1','001-1818111-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO




--User2

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Casey Egan','User2','324-56567-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Beth Webb','User2','939-19385-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Jeremy Franzen','User2','830-20384-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kyle Sommers','User2','293-82894-333','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Eric Gocke','User2','929-299222-929','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Steve Ethen','User2','281-393932-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kent Egan','User2','111-90119191-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mike Williams','User2','3434-60922992-555','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Bugs Bunny','User2','2929-919191-121','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Daffy Duck','User2','1919-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Elmer Fudd','User2','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[WireAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Cookie Monster','User2','676-19384483-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[CheckAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Big Bird','User2','001-1818111-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO

