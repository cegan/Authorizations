Use Authorizations

delete from [AchAuthorizations]


--EganC

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID] )
VALUES('Casey Egan','Eganc','324-56567-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Nick Egan','Eganc','939-19385-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kyle Egan','Eganc','830-20384-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Phillip Wolfe','Eganc','293-82894-333','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Jeremy Paulson','Eganc','929-299222-929','Please Approve this ASAP',6539.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Stephanie Paulson','Eganc','281-393932-221','Please Approve this ASAP',1458.08,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Lisa Szajkowski','Eganc','938-583012-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Edward Martinez','Eganc','912-103912-082','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Robert Szajkowski','Eganc','593-881091-121','Please Approve this ASAP',349.32,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Lori Morasco','Eganc','282-180028-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Becky Hansen','Eganc','919-583011-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Stephanie Culbertson','Eganc','676-729104-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Zeus Egan','Eganc','001-1818111-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO


INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kent Webb','Eganc','324-56567-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Beth Ethen','Eganc','939-19385-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Jeremy Williams','Eganc','830-20384-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kyle Franzen','Eganc','293-82894-333','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Eric Summers','Eganc','929-299222-929','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Steve Gocke','Eganc','281-393932-221','Please Approve this ASAP',5814.54,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Kent Webb','Eganc','111-90119191-221','Please Approve this ASAP',3248.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mike Friedman','Eganc','3434-60922992-555','Please Approve this ASAP',2000.78,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tim Nelson','Eganc','2929-919191-121','Please Approve this ASAP',349.68,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Denis Kirlin','Eganc','1919-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Doug Cory','Eganc','390-177590-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Ken Johnson','Eganc','676-916647-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Carmin Fogerty','Eganc','001-763278-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO








--User1

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Bugs Bunny','User1','501-687129-571','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Daffy Duck','User1','003-690912-165','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Elmer Fudd','User1','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Petunia Pig','User1','676-19384483-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Speedy Gonzales','User1','001-1818111-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tweety Pie','User1','324-56567-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Porky The Pig','User1','939-19385-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Little Blabbermouse','User1','830-20384-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Cecil Turtle','User1','293-82894-333','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Foghorn Leghorn','User1','929-299222-929','Please Approve this ASAP',3594.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Hippety Hopper','User1','281-393932-221','Please Approve this ASAP',9691.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Wile E. Coyote','User1','111-90119191-221','Please Approve this ASAP',2931.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Miss Prissy','User1','3434-60922992-555','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Bugs Bunny','User1','2929-919191-121','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Daffy Duck','User1','1919-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Elmer Fudd','User1','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Sam Sheepdog','User1','676-19384483-583','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Babbit and Catstello','User1','001-1818111-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO







--User2
INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Homer Simpson','User2','324-565617-939','Please Approve this ASAP',600.34,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Woody Woodpecker','User2','001-901127-372','Please Approve this ASAP',921.81,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Ren and Stimpy','User2','644-872004-173','Please Approve this ASAP',2000.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Fred and Barney','User2','939-193851-001','Please Approve this ASAP',203.23,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Betty Boop','User2','830-203584-493','Please Approve this ASAP',56897.95,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mickey Mouse','User2','293-828394-549','Please Approve this ASAP',234.92,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Scooby-Doo','User2','929-299222-004','Please Approve this ASAP',120.56,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Winnie the Pooh','User2','281-393932-221','Please Approve this ASAP',569.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Felix the Cat','User2','438-002836-841','Please Approve this ASAP',3812.93,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tweety and Sylvester','User2','929-928480-121','Please Approve this ASAP',349.01,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Donald Duck','User2','301-0019111-999','Please Approve this ASAP',492.21,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Elmer Fudd','User2','919-9911133-229','Please Approve this ASAP',900.98,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Mighty Mouse','User2','676-19384483-583','Please Approve this ASAP',907.33,'Transact',getDate(),0,1)
GO

INSERT INTO [Authorizations].[dbo].[AchAuthorizations]([Name],[ApproverId],[AccountNumber],[Notes],[Amount],[OriginatingSystem],[IssuedOn],[IsApproved],[ContactInformation_ID])
VALUES('Tom and Jerry','User2','871-3765651-221','Please Approve this ASAP',274.12,'Transact',getDate(),0,1)
GO


